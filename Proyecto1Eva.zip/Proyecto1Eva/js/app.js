document.addEventListener('DOMContentLoaded', function() {
  const menuToggle = document.querySelector('.menu-toggle');
  const menu = document.querySelector('.menu');

  menuToggle.addEventListener('click', function() {
      menu.classList.toggle('active'); 
  });
});

document.addEventListener('DOMContentLoaded', function() {
  const banner = document.querySelector('.bannerCalasanz');
  

  banner.addEventListener('click', function() {
      window.location.href = 'index.html'; 
  });
});

document.addEventListener("DOMContentLoaded", () => {
  if (document.body.classList.contains("index-body")) {
      document.body.style.overflow = "hidden";
  } else {
      document.body.style.overflow = "auto";
  }
});


function loadCalendar() {
  fetch('http://localhost:3000/actividades')
      .then(response => {
          if (!response.ok) {
              throw new Error(`Error al cargar datos: ${response.statusText}`);
          }
          return response.json();
      })
      .then(data => {
        console.log(data);
          renderCalendar(data);
      })
      .catch(error => {
          console.error('Error al cargar el calendario:', error);
      });
}

function renderCalendar(activities) {
  const calendarDiv = document.getElementById("calendar");

  // Generar encabezados para los días de la semana (empezando por lunes)
  const daysOfWeek = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"];
  daysOfWeek.forEach(day => {
    const headerDiv = document.createElement("div");
    headerDiv.className = "calendar-day-header";
    headerDiv.innerText = day;
    headerDiv.style.fontWeight = "bold";
    calendarDiv.appendChild(headerDiv);
  });

  // Identificar el primer día del mes (diciembre 2024 empieza en lunes)
  const firstDayOfMonth = new Date(2024, 11, 1).getDay(); // 0 = domingo, 1 = lunes...
  const offset = (firstDayOfMonth === 0 ? 6 : firstDayOfMonth - 1); // Ajustar para empezar en lunes

  // Añadir espacios vacíos para los días antes del 1 de diciembre
  for (let i = 0; i < offset; i++) {
    const emptyDiv = document.createElement("div");
    emptyDiv.className = "calendar-day empty";
    calendarDiv.appendChild(emptyDiv);
  }

  // Generar días del mes (diciembre)
  for (let i = 1; i <= 31; i++) {
    const day = i < 10 ? `0${i}` : i;
    const dateKey = `2024-12-${day}`;
    const dayDiv = document.createElement("div");
    dayDiv.className = "calendar-day";
    dayDiv.setAttribute("data-date", dateKey);

    if (activities[dateKey]) {
      // Resumen de actividades
      const summary = activities[dateKey]
        .map(a => `${a.hora} - ${a.actividad}`)
        .join("<br>");
      dayDiv.innerHTML = `<strong>${day}</strong><br>${summary}`;
    } else {
      dayDiv.innerHTML = `<strong>${day}</strong>`;
    }

    // Añadir evento al día
    dayDiv.addEventListener("click", () => showDetails(dateKey, activities[dateKey]));
    calendarDiv.appendChild(dayDiv);
  }
}
function showDetails(dateKey, activities) {
  const detailsDiv = document.getElementById("day-details");
  const title = document.getElementById("day-title");
  const activitiesDiv = document.getElementById("day-activities");

  // Establecer el título del modal
  title.innerText = `Detalles del ${dateKey}`;

  // Mostrar las actividades o un mensaje si no hay actividades
  activitiesDiv.innerHTML = activities
    ? activities
        .map(
          a =>
            `<p><strong>${a.hora}</strong>: ${a.actividad}<br>${a.descripcion}</p>`
        )
        .join("")
    : "<p>No hay actividades para este día.</p>";

  // Mostrar el modal de detalles
  detailsDiv.classList.remove("hidden");
}

function closeDetails() {
  // Cerrar el modal de detalles
  document.getElementById("day-details").classList.add("hidden");
}

// Añadir evento para cerrar el modal al cargar la página
document.addEventListener("DOMContentLoaded", () => {
  const closeBtn = document.getElementById("close-details");
  if (closeBtn) {
    closeBtn.addEventListener("click", closeDetails);
  }
});
